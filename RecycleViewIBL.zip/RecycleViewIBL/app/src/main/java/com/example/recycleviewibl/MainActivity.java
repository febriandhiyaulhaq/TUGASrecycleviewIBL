package com.example.recycleviewibl;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvibl;
    private ArrayList<IBLModel> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvibl = findViewById(R.id.ibl_list);
        rvibl.setHasFixedSize(true);
        list.addAll(IBLData.getListData());

        showRecyclerList();
    }

    private void showRecyclerList(){
        rvibl.setLayoutManager(new LinearLayoutManager(this));
        IBLAdapter IBLAdapter = new IBLAdapter(this);
        IBLAdapter.setIBLList(list);
        rvibl.setAdapter(IBLAdapter);
    }
}
