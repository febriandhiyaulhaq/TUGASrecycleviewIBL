package com.example.recycleviewibl;

import java.util.ArrayList;

public class IBLData {

    private static String[] title = new String[]{"Pelita Jaya", "Prawira Bandung",
            "Pacific Caesar Surabaya ", "Indonesia Patriots", "Bima Perkasa Jogjakarta", " Louvre Surabaya", "Satya Wacana Salatiga",
            "Hangtuah", "Satria Muda", "NSH Jakarta"
    };

    private static String[] detail = new String[]{
            "Pelita Jaya Basketball Club yang didirikan pada tahun 1987 adalah sebuah klub bola basket bentukan Kelompok Usaha Bakrie sebagai sumbangsih kepada dunia olahraga Indonesia, khususnya bola basket. Selama 30 tahun berdiri, Pelita Jaya Basketball Club sudah menjuarai berbagai turnamen, termasuk di antaranya tiga kali juara liga basket nasional.Sebagai salah satu klub bola basket besar di Indonesia, Pelita Jaya Basketball Club memiliki kelompok fans yang tersebar hampir di seluruh Indonesia. Mereka menyebut dirinya sebagai PJ Holic. Sampai saat ini, jumlahnya terus menerus bertambah seiring dengan meningkatnya performa klub yang mampu menggaet pecinta olahraga bola basket untuk juga menyukai Pelita Jaya Basketball Club\n",
            "PRAWIRA BANDUNG salah satu klub basket yang bertanding di IBL(INDONESIAN Basketball League), berdiri sejak tahun 2018, klub basket yang sebelumnya bernama Garuda Bandung pada musim kompetisi IBL 2018/2019 berganti nama menjadi Prawira Bandung. Walau tak banyak melakukan perubahan tim Prawira Bandung siap menjadi salah satu penantang kompetisi tertinggi basket di indonesia. Sebutan khusus untuk penggemar/pendukung klub Prawira Bandung adalah Family Prawira.\n",
            "Sejak usia 17 tahun, Bambang Susanto yakni mantan atlet basket nasional Indonesia membangun mimpi dan cintanya terhadap olahraga basket dengan mendirikan klub Pacific Caesar Surabaya pada tanggal 8 Mei 1968.\n",
            "Indonesia Patriots adalah Tim Nasional Indonesia yang akan berlaga di event Internasional mewakili negara Indonesia. Terdiri dari gabungan pemain-pemain terbaik mewakili daerah dan klubnya ini dinamakan Patriots untuk mewakili kebanggaan sebagai bangsa pejuang. Patriots mempunyai hashtag #bawabangga yang diciptakan oleh salah satu fansnya, dengan filosofi sebagai berikut:Pregame: Putra putri terbaik bangsa yang dipilih membawa kebanggan untuk mewakili Indonesia berjuang demi prestasi bolabasket tanah air.Postgame: Setiap pertandingan membawa kebanggaan bagi bangsa dan negara. Tetap rendah hati dan tidak berpuas diri jika menang namun berbesar hati dan mau mengevaluasi diri jika belum.Bank BPD DIY Bima Perkasa Jogjakarta sebelumnya bernama Bima Sakti Malang, namun pada tahun 2016 berganti nama menjadi Bank BPD DIY Bima Perkasa Jogjakarta dan sebagai satu-satunya klub asal Daerah Istimewa Yogyakarta. Klub Bima Perkasa memiliki sebutan khusus untuk para penggemarnya, yaitu Kanca Bima.\n",
            "Bank BPD DIY Bima Perkasa Jogjakarta sebelumnya bernama Bima Sakti Malang, namun pada tahun 2016 berganti nama menjadi Bank BPD DIY Bima Perkasa Jogjakarta dan sebagai satu-satunya klub asal Daerah Istimewa Yogyakarta. Klub Bima Perkasa memiliki sebutan khusus untuk para penggemarnya, yaitu Kanca Bima\n",
            "Berawal dari klub e-sport, Louvre Surabaya kini telah merambah ke olahraga basket. Klub basket profesional asal Surabaya ini didirikan pada tahun 2019 dan memulai debut pada kompetisi IBL musim 2020. Tim asuhan Andika Supriadi Saputra  ini bermarkas di DBL Arena\n",
            "Satya Wacana Salatiga adalah sebuah tim basket yang berhome base dikota Salatiga, Jawa Tengah. Tim ini mulai terbentuk pada tanggal 1 Agustus 2007. Sebelum berlaga di IBL Indonesia seperti saat ini, tim ini bernama pusdiklat Bola Basket FTI-UKSW. Saat itu tim FTI-UKSW hanya berlaga di tingkat mahasiswa, dan pada tahun pertamanya berhasil menduduki posisi runner up dalam kejurnas antar universitas yang diadakan di Surabaya.Berkembangnya setiap pemain yang ada dalam Pusdiklat Bola Basket FTI-UKSW tentu saja berbanding lurus dengan prestasi yang diraih dan membuka kesempatan untuk tim ini bertanding dalam kasta liga yang lebih tinggi. Dari tim yang bertanding di level mahasiswa, tim ini telah menjelma menjadi sebuah tim basket yang berlaga dalam liga kasta tertinggi bola basket nasional yaitu NBL Indonesia (2010-2015) dan IBL Indonesia (2016 - sekarang).Tim Satya Wacana Salatiga telah mengikuti 9 musim liga kasta tertinggi di Indonesia dari tahun 2010 - 2018. Dari tahun pertama yang menjadi juru kunci, dan terus berkembang di setiap musim berikutnya dan sekarang telah menjadi salah satu tim papan tengah IBL Indonesia. Satya Wacana Salatiga dapat terus berkembang karena tim ini beranggotakan pemain - pemain muda yang potensial. Selain pemain, tentunya tim ini juga didukung dengan tim pelatih yang profesional serta manajemen yang professional di bawah PT SMS (PT Satya Mitra Sejahtera). Saat ini IBL Idonesia diikuti oleh 10 tim, dan tim Satya Wacana adalah satu - satunya tim berbasis perguruan tinggi yang ikut berlaga di IBL Indonesia\n",
            "Hangtuah berdiri sejak tahun 2006, yang awalnya merupakan klub perwakilan kota Palembang, namun kini menjadi salah satu klub Jakarta\n",
            "Satria Muda didirikan pada 28 Oktober 1993 sebagai salah satu klub pendatang baru di KOBATAMA (Kompetisi Bola Basket Utama), yang merupakan liga basket tertinggi di Indonesia pada waktu itu. Perjalanan Satria Muda dimulai dari divisi 2 KOBATAMA, tahun 1995, Satria Muda berhasil mendapatkan tiket promosi ke divisi 1 KOBATAMA melalui pertandingan babak promosi-degradasi.Pada tahun 1998, Grup Mahaka yang dinahkodai oleh Erick Thohir bersama beberapa rekanan mengambil alih pengelolaan klub Satria Muda. Kini, Satria Muda Pertamina berada di bawah naungan PT. Indonesia Sport Venture dan secarakontinyu terus berkompetisi di liga basket indonesia atau IBL, serta menyumbangkan pemain-pemainnya untuk memperkuat tim nasional Indonesia pada berbagai kesempatan. Selama 26 tahun perjalanannya sebagai sebuah organisasi, Satria Muda telah mampu mengumpulkan 10 gelar juara Indonesia. Gelar-gelar juara ini merupakan salah satu bentuk manifestasi dari slogan yang dijunjung oleh organisasi Satria Muda, yaitu JUARA INDONESIA INDONESIA JUARA \n",
            "NSH Jakarta adalah nama yang berasal dari Na Sioe Hauw, yaitu pendiri sekaligus pemilik klub yang berdiri sejak tahun 1994 dibawah naungan PT. Namaskara Swakelola Harapan\n"



    };

    private static int[]thumbnail = new int[]{R.drawable.img1, R.drawable.img2,
            R.drawable.img3, R.drawable.img4, R.drawable.img5,
            R.drawable.img6, R.drawable.img7,
            R.drawable.img8, R.drawable.img9, R.drawable.img10,
    };


    public static ArrayList<IBLModel> getListData(){
        IBLModel IBLModel = null;
        ArrayList<IBLModel> list = new ArrayList<>();
        for (int i = 0;i<title.length;i++){
            IBLModel = new IBLModel();
            IBLModel.setThumbnail(thumbnail[i]);
            IBLModel.setTitle(title[i]);
            IBLModel.setDetail(detail[i]);
            list.add(IBLModel);
        }
        return list;
    }
}
